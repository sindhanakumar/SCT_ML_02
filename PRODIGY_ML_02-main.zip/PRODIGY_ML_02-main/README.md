# PRODIGY_ML_02
Task-02:  Create a K-means clustering algorithm to group customers of a retail store based on their purchase history.
